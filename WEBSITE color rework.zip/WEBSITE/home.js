const loginButton = document.querySelector('#login-button');
const registerButton = document.querySelector('#register-button');
const image = document.querySelector('.contact');

loginButton.addEventListener('click', () => {
    window.location.href = 'HomePage.html';
});

registerButton.addEventListener('click', () => {
    window.location.href = 'HomePage.html';
});
